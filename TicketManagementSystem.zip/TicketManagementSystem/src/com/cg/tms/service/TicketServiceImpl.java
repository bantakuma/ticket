package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.FieldCannotBeNullException;

public class TicketServiceImpl implements TicketService {

	TicketDAO ticketDAO;

	public TicketServiceImpl(TicketDAO ticketDAO) {
		super();
		this.ticketDAO = ticketDAO;
	}
	

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) throws FieldCannotBeNullException {
		// TODO Auto-generated method stub
		return ticketDAO.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		return ticketDAO.listTicketCategory();
	}

}
