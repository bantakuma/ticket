package com.cg.tms.exception;

public class FieldCannotBeNullException extends Exception {

}
