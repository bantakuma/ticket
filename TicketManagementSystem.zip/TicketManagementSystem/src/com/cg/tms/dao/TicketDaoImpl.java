package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.FieldCannotBeNullException;
;





public class TicketDaoImpl implements TicketDAO {

	private HashMap<Integer, TicketBean> ticketLog =new HashMap<>();
	
	private static Map<String,String> ticketCategory =new HashMap<>();
	
	
	public static Map<String, String> getTicketCategoryEntries()
	{
		ticketCategory.put("tc001", "Software Installation");
		ticketCategory.put("tc002", "Mailbox Creation");
		ticketCategory.put("tc003", "Mailbox Issue");
		
		
		return ticketCategory;
		
	}
	
	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) throws FieldCannotBeNullException {
		if(ticketBean.getTicketCategory()==null || ticketBean.getTicketCategory()==null || ticketBean.getTicketPriority()==null)
		{
			throw new FieldCannotBeNullException();
		}
		
		
		int ticketKey=(int)(Math.random()*1000);
		ticketBean.setTicketNo(Integer.toString(ticketKey));
		ticketLog.put(ticketKey, ticketBean);
		
		return true;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {

		List<TicketCategory> ticketCategoryList=new ArrayList<TicketCategory>();

		Iterator<Entry<String, String>> dataTrav=getTicketCategoryEntries().entrySet().iterator();
		while(dataTrav.hasNext())
		{
			Map.Entry<String, String> data=(Map.Entry<String, String>)dataTrav.next();
				ticketCategoryList.add(new TicketCategory(data.getKey(),data.getValue()));
		}
		
		
		return ticketCategoryList;
	}

}
