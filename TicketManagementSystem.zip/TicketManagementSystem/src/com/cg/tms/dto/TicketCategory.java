package com.cg.tms.dto;

public class TicketCategory {
	
	private String ticketCategoryID;
	private String categoryName;
	
	
	//Getter Setter
	public String getTicketCategoryID() {
		return ticketCategoryID;
	}
	public void setTicketCategoryID(String ticketCategoryID) {
		this.ticketCategoryID = ticketCategoryID;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
	//Constructors
	public TicketCategory() {
		super();
	}
	
	public TicketCategory(String ticketCategoryID, String categoryName) {
		super();
		this.ticketCategoryID = ticketCategoryID;
		this.categoryName = categoryName;
	}
	
	//ToString Method
	@Override
	public String toString() {
		return "TicketCategory [ticketCategoryID=" + ticketCategoryID + ", categoryName=" + categoryName + "]";
	}
	
	
	
	

}
