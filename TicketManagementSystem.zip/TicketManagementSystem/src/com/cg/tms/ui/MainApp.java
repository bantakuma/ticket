package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDaoImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.FieldCannotBeNullException;
import com.cg.tms.service.TicketServiceImpl;



public class MainApp {
	
	private static Scanner scanner=new Scanner(System.in);
	private static TicketDAO ticketDAO=new TicketDaoImpl();
	private static TicketServiceImpl ticketService= new TicketServiceImpl(ticketDAO);

	public static void main(String[] args) throws FieldCannotBeNullException {
		// TODO Auto-generated method stub
		
		
		
		int choice;
		
		ticketService.listTicketCategory();
		
		while(true)
		{
			System.out.println("Welcome to ITIMD Help Desk");
			System.out.println("1: Raise a ticket");
			System.out.println("2: Exit");
			
			choice=scanner.nextInt();
			
			switch(choice)
			{
			case 1:raiseTicket();
				break;
			case 2:System.exit(0);
				break;
			default: System.out.println("Wrong Choice");
				break;
			}
			
			
		}

	}

	private static void raiseTicket() throws FieldCannotBeNullException {
		// TODO Auto-generated method stub
		//Decleration
		List<TicketCategory> ticketCategoryList=ticketService.listTicketCategory();
		
		TicketBean ticket= new TicketBean();
		TicketCategory ticketCategoryTemp=new TicketCategory();
		System.out.println("Select Ticket Category from below list:");
		ListIterator<TicketCategory> lisit=ticketCategoryList.listIterator();
		for(int i=1;i<ticketCategoryList.size()+1 && lisit.hasNext();i++)
		{
			System.out.print(i+ " ");
			System.out.println(lisit.next().getCategoryName());
		}
		System.out.println("Enter option:");
		int choiceCategory=scanner.nextInt();
		
		System.out.println("Enter Descreption related to issue");
		String ticketDescreption=scanner.next();
		
		System.out.println("Enter Priority\n 1:low\n 2:medium\n 3:high");
		String ticketPriority=scanner.next();
		
		System.out.println(ticketCategoryList.get(0).getTicketCategoryID());
		
		
		
	
		
		ticketCategoryTemp.setCategoryName(ticketCategoryList.get(choiceCategory-1).getCategoryName());
		ticketCategoryTemp.setTicketCategoryID(ticketCategoryList.get(choiceCategory-1).getTicketCategoryID());
		ticket.setTicketCategory(ticketCategoryTemp);
		ticket.setTicketDescription(ticketDescreption);
		ticket.setTicketPriority(ticketPriority);
		ticket.setTicketStatus("New");
		ticket.setItimdComments("N/A");
		
		LocalDateTime now = LocalDateTime.now();   
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:a");
		
		if(ticketService.raiseNewTicket(ticket))
		{
			System.out.println("Ticket Number "+ ticket.getTicketNo() +" logged syccessfully at "+now.format(format));
		}
		
		
		
	}

	
}
